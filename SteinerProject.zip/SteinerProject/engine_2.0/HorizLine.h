#ifndef HORIZLINE_H
#define HORIZLINE_H

struct HorizLine {
    int y;
    int x1;
    int x2;
};

#endif
