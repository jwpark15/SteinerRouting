#ifndef VERTLINE_H
#define VERTLINE_H

struct VertLine {
    int x;
    int y1;
    int y2;
};

#endif
